import asyncio

import os
import time
import requests
from config import START_IMG_URL
from pyrogram import filters
import random
from pyrogram import Client
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup
from strings.filters import command
from SrcMusicKERO import (Apple, Resso, SoundCloud, Spotify, Telegram, YouTube, app)
from SrcMusicKERO import app
from random import  choice, randint

                
@app.on_message(filters.command(["✨ سورس", "مطور السورس", "السورس"]))
async def send_source_video(client: Client, message: Message):
    await message.reply_video(
        video="https://te.legra.ph/file/d04bea15f20fb094a047c.mp4",
        caption="⍟ 𝚃𝙷𝙴 𝙱𝙴𝚂𝚃 𝚂𝙾𝚄𝚁𝙲𝙴 𝙾𝙽 𝚃𝙴𝙻𝙴𝙶𝚁𝙰𝙼",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("مـطور السـورس", url="https://t.me/Fox4566"),
                    InlineKeyboardButton("مبزمج السورس", url="https://t.me/Loo_la3")
                ],
                [
                    InlineKeyboardButton("قـناه السـورس", url="https://t.me/PX_CBL")
                ],
                [
                    InlineKeyboardButton("اضغط لاضافتي لمجموعتك⚡", url=f"https://t.me/{app.username}?startgroup=true")
                ]
            ]
        )
    )

# Command to show developer info (M_9_T)
@app.on_message(filters.command(["المطور فوكس"]))
async def show_developer_info(client: Client, message: Message):
    usr = await client.get_chat("Fox4566")
    name = usr.first_name
    photo = await app.download_media(usr.photo.big_file_id)
    await message.reply_photo(
        photo,
        caption=f"معلومات مطور السورس\n\n‍ ¦➻ 𝐍𝐀𝐌𝐄 :{name}\n\n ¦➻ 𝐔𝐒𝐄𝐑 :@{usr.username}\n\n ¦➻ 𝐈𝐃 :`{usr.id}`\n\n ¦➻ 𝐁𝐎𝐈 :{usr.bio}\n\nســورس ميــوزك Titanx",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(name, url=f"https://t.me/{usr.username}")
                ]
            ]
        ),
    )

# Command to show developer info (Hokam)
@app.on_message(filters.command(["🦊", "فوكس", "مبرمج السورس"]))
async def show_programmer_info(client: Client, message: Message):
    usr = await client.get_chat("Fox4566")
    name = usr.first_name
    photo = await app.download_media(usr.photo.big_file_id)
    await message.reply_photo(
        photo,
        caption=f"معلومات مبرمج السورس.\n\n¦➻ 𝐍𝐀𝐌𝐄 :{name}\n\n ¦➻ 𝐔𝐒𝐄𝐑 :@{usr.username}\n\n ¦➻ 𝐈𝐃 :`{usr.id}`\n\n ¦➻ 𝐁𝐎𝐈 :{usr.bio}\n\nسـورس مـيوزك Titanx",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(name, url=f"https://t.me/{usr.username}")
                ]
            ]
        ),
    )
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message

# Command to show developer info (Hokam)
@app.on_message(filters.command(["حكم", "فوكس", "مبرمج السورس"]))
async def show_programmer_info(client: Client, message: Message):
    try:
        usr = await client.get_chat("Fox4566")
        name = usr.first_name
        photo = usr.photo.big_file_id if usr.photo else None
        if photo:
            photo_path = await app.download_media(photo)
            await message.reply_photo(
                photo_path,
                caption=f"معلومات مبرمج السورس.\n\n¦➻ 𝐍𝐀𝐌𝐄 : {name}\n\n¦➻ 𝐔𝐒𝐄𝐑 : @{usr.username}\n\n¦➻ 𝐈𝐃 : `{usr.id}`\n\n¦➻ 𝐁𝐎𝐈 : {usr.bio if usr.bio else 'لا توجد معلومات'}\n\nسـورس مـيوزك العـالم",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(name, url=f"https://t.me/{usr.username}")
                        ]
                    ]
                ),
            )
        else:
            await message.reply(
                f"معلومات مبرمج السورس.\n\n¦➻ 𝐍𝐀𝐌𝐄 : {name}\n\n¦➻ 𝐔𝐒𝐄𝐑 : @{usr.username}\n\n¦➻ 𝐈𝐃 : `{usr.id}`\n\n¦➻ 𝐁𝐎𝐈 : {usr.bio if usr.bio else 'لا توجد معلومات'}\n\nسـورس مـيوزك العـالم",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(name, url=f"https://t.me/{usr.username}")
                        ]
                    ]
                ),
            )
    except Exception as e:
        await message.reply(f"حدث خطأ: {e}")

# Command to show developer info (Ahmed)
@app.on_message(filters.command(["مطور السورس", "alaa", "بودا"]))
async def show_programmer_info_ahmed(client: Client, message: Message):
    try:
        usr = await client.get_chat("Loo_la3")
        name = usr.first_name
        photo = usr.photo.big_file_id if usr.photo else None
        if photo:
            photo_path = await app.download_media(photo)
            await message.reply_photo(
                photo_path,
                caption=f"معلومات مبرمج السورس.\n\n¦➻ 𝐍𝐀𝐌𝐄 : {name}\n\n¦➻ 𝐔𝐒𝐄𝐑 : @{usr.username}\n\n¦➻ 𝐈𝐃 : `{usr.id}`\n\n¦➻ 𝐁𝐎𝐈 : {usr.bio if usr.bio else 'لا توجد معلومات'}\n\nسـورس مـيوزك Titanx",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(name, url=f"https://t.me/{usr.username}")
                        ]
                    ]
                ),
            )
        else:
            await message.reply(
                f"معلومات مبرمج السورس.\n\n¦➻ 𝐍𝐀𝐌𝐄 : {name}\n\n¦➻ 𝐔𝐒𝐄𝐑 : @{usr.username}\n\n¦➻ 𝐈𝐃 : `{usr.id}`\n\n¦➻ 𝐁𝐎𝐈 : {usr.bio if usr.bio else 'لا توجد معلومات'}\n\nسـورس مـيوزك Titanx",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(name, url=f"https://t.me/{usr.username}")
                        ]
                    ]
                ),
            )
    except Exception as e:
        await message.reply(f"حدث خطأ: {e}")
