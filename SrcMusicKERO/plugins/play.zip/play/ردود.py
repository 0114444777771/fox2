import asyncio
import random
from SrcMusicKERO import app
from pyrogram.types import (InlineKeyboardButton,
                            InlineKeyboardMarkup, Message)
from pyrogram import filters, Client




txt = [
" هآي تع اشب شااي • 😹💔",
"هلا بالغالي ❤️.",
"اهلا يا اخويا 😏"
        ]
@app.on_message(filters.command(["هاي"], ""), group=73)

async def VeGa(client: Client, message: Message):

      a = random.choice(txt)

      await message.reply(

        f"{a}")
        
        
thxt = [
" وعليكم السلام 🌝💜",
" حياك حبيبي ✨❤️.",
" تفضل يبرو 😎"
        ]
@app.on_message(filters.command(["السلام عليكم"], ""), group=173)

async def VeGa(client: Client, message: Message):

      a = random.choice(thxt)

      await message.reply(

        f"{a}")        
     
htxt = [
" خدوني معاكم برايفت والنبي 🥺💔",
" شغل الحك اشتغل 😁",
" بطلوا قرف بقي 😂",
        ]

@app.on_message(filters.command(["برايفت"], ""), group=273)

async def VeGa(client: Client, message: Message):

      a = random.choice(htxt)

      await message.reply(

        f"{a}")   
        
htt = [
" نزل عينك تحت كدا علشان هتخاد علي قفاك 😒❤️"
        ]

@app.on_message(filters.command(["🙄"], ""), group=373)

async def VeGa(client: Client, message: Message):

      a = random.choice(htt)

      await message.reply(

        f"{a}")           
        
htx = [
" مع الف سلامه يقلبي متجيش تاني 😹💔🎶",
" يلا في داهيه 😏",
" المركب اللي تودي"
        ]

@app.on_message(filters.command(["سلام"], ""), group=253)

async def VeGa(client: Client, message: Message):

      a = random.choice(htx)

      await message.reply(

        f"{a}")        

ht = [
" عليه الصلاه والسلام 🌝💛"
        ]

@app.on_message(filters.command(["صلي علي النبي"], ""), group=673)

async def VeGa(client: Client, message: Message):

      a = random.choice(ht)

      await message.reply(

        f"{a}")

hxt = [
" نعم الله عليك 🌚❤️",
" يختي قميله 😎",
" اي الادب دا 😂" 
        ]

@app.on_message(filters.command(["نعم"], ""), group=2073)

async def VeGa(client: Client, message: Message):

      a = random.choice(txt)

      await message.reply(

        f"{a}")

hytxt = [
" القمر ده شبهك 🙂❤️"
        ]

@app.on_message(filters.command(["🌚"], ""), group=2173)

async def VeGa(client: Client, message: Message):

      a = random.choice(hytxt)

      await message.reply(

        f"{a}")   

hgtxt = [
" بتفكر في اي 🤔"
        ]

@app.on_message(filters.command(["🤔"], ""), group=2573)

async def VeGa(client: Client, message: Message):

      a = random.choice(hgtxt)

      await message.reply(

        f"{a}")   

ghtxt = [
" ضحكتك عثل زيكك ينوحيي 🌝❤️"
        ]

@app.on_message(filters.command(["😂"], ""), group=26773)

async def VeGa(client: Client, message: Message):

      a = random.choice(ghtxt)

      await message.reply(

        f"{a}")   

jhtxt = [
" متزعلش بحبك 😻🤍"
        ]

@app.on_message(filters.command(["🥺"], ""), group=26473)

async def VeGa(client: Client, message: Message):

      a = random.choice(jhtxt)

      await message.reply(

        f"{a}")   

ahtxt = [
" بتعيط تيب لي طيب 😥"
        ]

@app.on_message(filters.command(["😭"], ""), group=23573)

async def VeGa(client: Client, message: Message):

      a = random.choice(ahtxt)

      await message.reply(

        f"{a}")   

shtxt = [
" نا عايز مح انا كمان 🥺💔"
        ]

@app.on_message(filters.command(["💋"], ""), group=29773)

async def VeGa(client: Client, message: Message):

      a = random.choice(shtxt)

      await message.reply(

        f"{a}")   

dhtxt = [
" عدل وشك ونت بتكلمني 😒🙄"
        ]

@app.on_message(filters.command(["😒"], ""), group=2873)

async def VeGa(client: Client, message: Message):

      a = random.choice(dhtxt)

      await message.reply(

        f"{a}")
mhtxt = [
"محات حياتي يروحي 🌝❤️"
        ]

@app.on_message(filters.command(["محح"], ""), group=2601473)

async def VeGa(client: Client, message: Message):

      a = random.choice(mhtxt)

      await message.reply(

        f"{a}")   

lhtxt = [
" وانا كمان بعشقك يا روحي 🤗🥰",
" م بحب حد 😂",
"  بابا نور يزعل مني حبك برص 😁",
" قلب نور الحاكم  انتي ♥️🐣",
" الحب انتهي يبرو 😎"
        ]

@app.on_message(filters.command(["بحبك"], ""), group=231673)

async def VeGa(client: Client, message: Message):

      a = random.choice(lhtxt)

      await message.reply(

        f"{a}")   

xhtxt = [
" دايما ياحبيبي 🌝❤️",
" يديم الحمد ❤️.",
" بارك الله في صحتك 💕",
" ادام الله لك العافيه 🖤"
        ]

@app.on_message(filters.command(["الحمدلله"], ""), group=274683)

async def VeGa(client: Client, message: Message):

      a = random.choice(xhtxt)

      await message.reply(

        f"{a}")   

dfhtxt = [
" بنهش كتاكيت احنا هنا ولا اي ??😹"
        ]

@app.on_message(filters.command(["هشش"], ""), group=2756033)

async def VeGa(client: Client, message: Message):

      a = random.choice(dfhtxt)

      await message.reply(

        f"{a}")   

nhtxt = [
" هلا بيك ياروحي 👋"
        ]

@app.on_message(filters.command(["هلا"], ""), group=207973)

async def VeGa(client: Client, message: Message):

      a = random.choice(nhtxt)

      await message.reply(

        f"{a}")   

phtxt = [
" وحيات امك ياكبتن خدوني معاكو بيف 🥺💔"
        ]

@app.on_message(filters.command(["بف"], ""), group=270973)

async def VeGa(client: Client, message: Message):

      a = random.choice(phtxt)

      await message.reply(

        f"{a}")   

ihtxt = [
" ونجيب اشخاص 😂👻"
        ]

@app.on_message(filters.command(["خاص"], ""), group=273573)

async def VeGa(client: Client, message: Message):

      a = random.choice(ihtxt)

      await message.reply(

        f"{a}")   

uhtxt = [
" انت الخير يعمري 🌝❤️"
        ]

@app.on_message(filters.command(["بخير"], ""), group=279373)

async def VeGa(client: Client, message: Message):

      a = random.choice(uhtxt)

      await message.reply(

        f"{a}")   

rhtxt = [
" اه اي يا قدع عيب 😹💔",
" الشارع اللي وراه 😂",
" هواء 😎"
        ]

@app.on_message(filters.command(["اه"], ""), group=267473)

async def VeGa(client: Client, message: Message):

      a = random.choice(rhtxt)

      await message.reply(

        f"{a}")   

htxtk = [
"خخخ امال 😹",
"كداب في وشك 🧐",
" عيني في عينك كده 😂"
        ]

@app.on_message(filters.command(["حصل"], ""), group=225973)

async def VeGa(client: Client, message: Message):

      a = random.choice(htxtk)

      await message.reply(

        f"{a}")

asdhtxt = [
" لا عيب بتكسف 😹💔",
" لا تع انت 😎😂",
" بس يا هليتها 😔",
" انت فيك 🤬😎"
        ]

@app.on_message(filters.command(["تع"], ""), group=200873)

async def VeGa(client: Client, message: Message):

      a = random.choice(asdhtxt)

      await message.reply(

        f"{a}")   

pokghtxt = [
" ده نورك ي قلبي 🌝💙"
        ]

@app.on_message(filters.command(["منور"], ""), group=200173)

async def VeGa(client: Client, message: Message):

      a = random.choice(pokghtxt)

      await message.reply(

        f"{a}")   

ijkhtxt = [
" اي الثقافه دي 😒😹"
        ]

@app.on_message(filters.command(["ويت"], ""), group=200273)

async def VeGa(client: Client, message: Message):

      a = random.choice(ijkhtxt)

      await message.reply(

        f"{a}")   

kghtxt = [
"ع فين لوين رايح وسايبنى 🥺💔"
        ]

@app.on_message(filters.command(["باي"], ""), group=200373)

async def VeGa(client: Client, message: Message):

      a = random.choice(kghtxt)

      await message.reply(

        f"{a}")   

lphtxt = [
" اهدا يوحش ميصحش كدا 😒??"
        ]

@app.on_message(filters.command(["خخخ"], ""), group=200473)

async def VeGa(client: Client, message: Message):

      a = random.choice(lphtxt)

      await message.reply(

        f"{a}")   

tthtxt = [
" العفو ياروحي 🙈🌝"
        ]

@app.on_message(filters.command(["شكرا"], ""), group=200573)

async def VeGa(client: Client, message: Message):

      a = random.choice(tthtxt)

      await message.reply(

        f"{a}")   

qqhtxt = [
" انت الي حلو ياقمر 🤤🌝"
        ]

@app.on_message(filters.command(["حلوه"], ""), group=200673)

async def VeGa(client: Client, message: Message):

      a = random.choice(qqhtxt)

      await message.reply(

        f"{a}")   

wwhtxt = [
" موت بعيد م ناقصين مصايب 😑😂"
        ]

@app.on_message(filters.command(["بموت"], ""), group=200773)

async def VeGa(client: Client, message: Message):

      a = random.choice(wwhtxt)

      await message.reply(

        f"{a}")   

zzhtxt = [
"فرح خالتك قريب 😹💋💃🏻"
        ]

@app.on_message(filters.command(["تيب"], ""), group=200873)

async def VeGa(client: Client, message: Message):

      a = random.choice(zzhtxt)

      await message.reply(

        f"{a}")   

vvhtxt = [
" جتك اوهه م سامع ولا ايي 😹👻",
" اتك عليه 😏😎",
" ع الانتريه 🤔😎"
        ]

@app.on_message(filters.command(["اي"], ""), group=200973)

async def VeGa(client: Client, message: Message):

      a = random.choice(vvhtxt)

      await message.reply(

        f"{a}")   

xxhtxt = [
" حضرلك الخير يارب 🙂❤️"
        ]

@app.on_message(filters.command(["حاضر"], ""), group=2000173)

async def VeGa(client: Client, message: Message):

      a = random.choice(xxhtxt)

      await message.reply(

        f"{a}")   

cchtxt = [
" لف ورجع تانى مشحوار 😂🚶‍♂👻",
" اصلها ناقصه قرفك 😂",
" شرفت ❤️.",
" يعني انت البخاري 😂"
        ]

@app.on_message(filters.command(["جيت"], ""), group=2000273)

async def VeGa(client: Client, message: Message):

      a = random.choice(cchtxt)

      await message.reply(

        f"{a}")   

kjjhtxt = [
"يوه خضتني ياسمك اي 🥺💔",
" بس يا اهطل 😂",
" شخخخخخ 😂"
        ]

@app.on_message(filters.command(["بخ"], ""), group=2000373)

async def VeGa(client: Client, message: Message):

      a = random.choice(kjjhtxt)

      await message.reply(

        f"{a}")   

ffhtxt = [
" خلصتت روحكك يبعيد 😹💔"
        ]

@app.on_message(filters.command(["خلاص"], ""), group=2000473)

async def VeGa(client: Client, message: Message):

      a = random.choice(ffhtxt)

      await message.reply(

        f"{a}")   

pphtxt = [
" امك اسمها احلام 😹😹",
" تمام منين بالظبط 😂",
" فل الفل 😎"
        ]

@app.on_message(filters.command(["تمام"], ""), group=2000573)

async def VeGa(client: Client, message: Message):

      a = random.choice(pphtxt)

      await message.reply(

        f"{a}")   

oohtxt = [
" اوه ياه 🌝😂"
        ]

@app.on_message(filters.command(["حبيبي"], ""), group=20703)

async def VeGa(client: Client, message: Message):

      a = random.choice(oohtxt)

      await message.reply(

        f"{a}")   

llhtxt = [
" كفيه شقط سيب حاجه لي بابا نور الحاكم ♥️🦦"
        ]

@app.on_message(filters.command(["سيفي"], ""), group=20713)

async def VeGa(client: Client, message: Message):

      a = random.choice(llhtxt)
      
      await message.reply(

        f"{a}")   

kkhtxt = [
"كفيه شقط سيب حاجه لي بابا نور الحاكم 🐣😹"
        ]

@app.on_message(filters.text, group=57355566)
async def d5on(client, message):
   if message.text == "😒":
       await message.reply_text(f"عدل وشك ونت بتكلمني 😒🙄")
   elif message.text == "💋":
       await message.reply_text(f" نا عايز مح انا كمان 🥺💔")
   elif message.text ==  "😭":
       await message.reply_text(f"بتعيط تيب لي طيب 😥")
   elif message.text == "🥺":
       await message.reply_text(f"متزعلش بحبك 😻🤍")
   elif message.text == "😂":
       await message.reply_text(f"ضحكتك عثل زيكك ينوحيي 🌝❤️")
   elif message.text == "🤔":
       await message.reply_text(f"بتفكر في اي 🤔")
   elif message.text == "🌚":
       await message.reply_text(f"القمر ده شبهك 🙂❤️")
   elif message.text == "نعم":
       await message.reply_text(f" نعم الله عليك 🌚❤️")
   elif "." in message.text:
       await message.reply_text(f"صلي علي النبي وتبسم ✨♥")
   elif message.text == "سلام":
       await message.reply_text(f" مع الف سلامه يقلبي متجيش تاني 😹💔🎶")
   elif message.text == "🙄":
       await message.reply_text(f" نزل عينك تحت كدا علشان هتخاد علي قفاك 😒❤️")
   elif message.text == "برايفت":
       await message.reply_text(f"خدوني معاكم برايفت والنبي 🥺💔")
   elif message.text == "السلام عليكم":
       await message.reply_text(f"وعليكم السلام 🌝💜")
   elif message.text == "هاي":
       await message.reply_text(f"هآي تع اشب شااي • 😹💔")        
   elif message.text == "محح":
       await message.reply_text(f" محات حياتي يروحي 🌝❤️")
   elif message.text == "بحبك":
       await message.reply_text(f"وانا كمان بعشقك يا روحي 🤗🥰")
   elif message.text == "الحمدلله":
       await message.reply_text(f"دايما ياحبيبي 🌝❤️")
   elif message.text == "هشش":
       await message.reply_text(f" بنهش كتاكيت احنا هنا ولا اي ??😹")        
   elif message.text == "هلا":
       await message.reply_text(f" هلا بيك ياروحي 👋")
   elif message.text == "بف":
       await message.reply_text(f"وحيات امك ياكبتن خدوني معاكو بيف 🥺💔")
   elif message.text == "خاص":
       await message.reply_text(f"ونجيب اشخاص 😂👻")
   elif message.text == "بخير":
       await message.reply_text(f"انت الخير يعمري 🌝❤️")        
   elif message.text == "اه":
       await message.reply_text(f" اه اي يا قدع عيب 😹💔")
   elif message.text == "حصل":
       await message.reply_text(f"خخخ امال 😹")        
   elif message.text == "تع":
       await message.reply_text(f"لا عيب بتكسف 😹💔")
   elif message.text == "منور":
       await message.reply_text(f" ده نورك ي قلبي 🌝💙")        
   elif message.text == "ويت":
       await message.reply_text(f" اي الثقافه دي 😒😹")
   elif message.text == "خخخ":
       await message.reply_text(f" اهدا يوحش ميصحش كدا 😒?")        
   elif message.text == "باي":
       await message.reply_text(f"ع فين لوين رايح وسايبنى 🥺💔")
   elif message.text == "شكرا":
       await message.reply_text(f"العفو ياروحي 🙈🌝")        
   elif message.text == "حلوه":
       await message.reply_text(f" انت الي حلو ياقمر 🤤🌝")
   elif message.text == "بموت":
       await message.reply_text(f"موت بعيد م ناقصين مصايب 😑😂")        
   elif message.text == "تيب":
       await message.reply_text(f"فرح خالتك قريب 😹💋💃🏻")
   elif message.text == "اي":
       await message.reply_text(f"جتك اوهه م سامع ولا ايي 😹👻")        
   elif message.text == "حاضر":
       await message.reply_text(f"حضرلك الخير يارب 🙂❤️")
   elif message.text == "سي في":
       await message.reply_text(f"كفيه شقط سيب حاجه لغيرك 😎😂")        
   elif message.text == "جيت":
       await message.reply_text(f"لف ورجع تانى مشحوار 😂🚶‍♂👻")
   elif message.text == "بخ":
       await message.reply_text(f"يوه خضتني ياسمك اي 🥺💔")        
   elif message.text == "خلاص":
       await message.reply_text(f"خلصتت روحكك يبعيد 😹💔")
   elif message.text == "حبيبي":
       await message.reply_text(f"اوه ياه 🌝😂")
   elif message.text == "تمام":
       await message.reply_text(f"امك اسمها احلام 😹😹")
 #كود ردود بسيط للسورس الميوزك بنسخه انوكس 
#مقدم من ديفل   @nor_o
